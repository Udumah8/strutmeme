"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Twitter, MessageCircle, Mail, Star, Users, Coins, TrendingUp, Gift } from "lucide-react"

export default function StrutMasterCoin() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleAirdropSignup = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      // Here you would typically send the email to your backend
      console.log("Airdrop signup:", email)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/5 to-primary/5" />
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <Badge className="mb-6 text-lg px-4 py-2 bg-primary text-primary-foreground">
                🚀 Now Live on Blockchain
              </Badge>
              <h1 className="text-6xl lg:text-7xl font-bold mb-6 text-balance">
                <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">STRUT</span>
                <br />
                Master Coin
              </h1>
              <p className="text-2xl lg:text-3xl font-semibold mb-4 text-primary">Be the Strut. Own the Moment.</p>
              <p className="text-lg text-muted-foreground mb-8 max-w-lg mx-auto lg:mx-0">
                The most confident meme coin in the crypto space. Join our community of strutters and ride the wave to
                the moon! 🌙
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button size="lg" className="text-lg px-8 py-6 bg-primary hover:bg-primary/90">
                  <Coins className="mr-2 h-5 w-5" />
                  Buy STRUT
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-6 border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                >
                  <Gift className="mr-2 h-5 w-5" />
                  Join Airdrop
                </Button>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full blur-3xl" />
                <img
                  src="/images/bird-hero.jpeg"
                  alt="Strut Master - The Confident Bird Mascot"
                  className="relative z-10 w-80 h-80 lg:w-96 lg:h-96 object-cover rounded-full shadow-2xl animate-float"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">About Strut Master</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              More than just a meme coin - we're building a community of confident crypto enthusiasts who know how to
              strut their stuff in the digital world.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>Community Driven</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Built by the community, for the community. Every decision is made together.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>Strong Vibes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Positive energy and confident attitude drive everything we do in the STRUT ecosystem.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Star className="h-12 w-12 text-primary mx-auto mb-4" />
                <CardTitle>Locked Liquidity</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Your investment is safe with our locked liquidity and transparent tokenomics.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Tokenomics Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">Tokenomics</h2>
            <p className="text-xl text-muted-foreground">Total Supply: 1,000,000,000 STRUT</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-primary">40%</CardTitle>
                <CardDescription>Liquidity Pool</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={40} className="mb-2" />
                <p className="text-sm text-muted-foreground">400M STRUT locked for trading</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-secondary">30%</CardTitle>
                <CardDescription>Airdrop & Community</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={30} className="mb-2" />
                <p className="text-sm text-muted-foreground">300M STRUT for early supporters</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-chart-3">20%</CardTitle>
                <CardDescription>Team & Development</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={20} className="mb-2" />
                <p className="text-sm text-muted-foreground">200M STRUT vested over 2 years</p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <CardTitle className="text-chart-4">10%</CardTitle>
                <CardDescription>Marketing & Partnerships</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={10} className="mb-2" />
                <p className="text-sm text-muted-foreground">100M STRUT for growth</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Roadmap Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">Roadmap</h2>
            <p className="text-xl text-muted-foreground">Our journey to the moon, one strut at a time</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-primary" />
              <CardHeader>
                <Badge className="w-fit mb-2 bg-primary text-primary-foreground">Phase 1</Badge>
                <CardTitle>Launch</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>✅ Token Creation</li>
                  <li>✅ Website Launch</li>
                  <li>✅ Community Building</li>
                  <li>✅ Initial Marketing</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-secondary" />
              <CardHeader>
                <Badge className="w-fit mb-2 bg-secondary text-secondary-foreground">Phase 2</Badge>
                <CardTitle>Airdrop</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>🔄 Airdrop Campaign</li>
                  <li>🔄 Exchange Listings</li>
                  <li>🔄 Influencer Partnerships</li>
                  <li>🔄 Community Events</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-chart-3" />
              <CardHeader>
                <Badge className="w-fit mb-2 bg-chart-3 text-white">Phase 3</Badge>
                <CardTitle>Community Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>⏳ Major Exchange Listings</li>
                  <li>⏳ Community Governance</li>
                  <li>⏳ Merchandise Store</li>
                  <li>⏳ Global Marketing</li>
                </ul>
              </CardContent>
            </Card>
            <Card className="relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-chart-4" />
              <CardHeader>
                <Badge className="w-fit mb-2 bg-chart-4 text-white">Phase 4</Badge>
                <CardTitle>Utility & NFTs</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>⏳ STRUT NFT Collection</li>
                  <li>⏳ Staking Rewards</li>
                  <li>⏳ Gaming Integration</li>
                  <li>⏳ DeFi Partnerships</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">Meet Our Mascot</h2>
            <p className="text-xl text-muted-foreground">The confident bird that represents our community spirit</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-square overflow-hidden">
                <img
                  src="/images/strut-mascot.gif"
                  alt="Strut Master strutting confidently"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">The Classic Strut</h3>
                <p className="text-sm text-muted-foreground">Our mascot showing off the signature confident walk</p>
              </CardContent>
            </Card>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-square overflow-hidden">
                <img
                  src="/images/bird-gallery-1.jpeg"
                  alt="Strut Master in contemplation"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">Deep Thoughts</h3>
                <p className="text-sm text-muted-foreground">Planning the next big move in the crypto space</p>
              </CardContent>
            </Card>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-square overflow-hidden">
                <img
                  src="/images/bird-gallery-2.jpeg"
                  alt="Strut Master ready for action"
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">Ready for Action</h3>
                <p className="text-sm text-muted-foreground">Always prepared to take on new challenges</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Airdrop Signup Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <Card className="text-center p-8 bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
            <CardHeader>
              <div className="mx-auto mb-6">
                <Gift className="h-16 w-16 text-primary mx-auto animate-bounce" />
              </div>
              <CardTitle className="text-3xl lg:text-4xl mb-4">Join the STRUT Airdrop!</CardTitle>
              <CardDescription className="text-lg">
                Be among the first to receive free STRUT tokens. Limited spots available!
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!isSubmitted ? (
                <form onSubmit={handleAirdropSignup} className="max-w-md mx-auto">
                  <div className="flex gap-4 mb-4">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="flex-1"
                    />
                    <Button type="submit" size="lg" className="px-8">
                      Join Now
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">No spam, just STRUT updates and airdrop notifications</p>
                </form>
              ) : (
                <div className="max-w-md mx-auto">
                  <div className="text-primary text-6xl mb-4">🎉</div>
                  <h3 className="text-2xl font-semibold mb-2 text-primary">Welcome to the Strut!</h3>
                  <p className="text-muted-foreground">
                    You're now registered for the airdrop. Keep an eye on your inbox for updates!
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">Meet the Strut Squad</h2>
            <p className="text-xl text-muted-foreground">The confident team behind STRUT Master Coin</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center text-4xl">
                  🧑‍💻
                </div>
                <CardTitle>Alex "The Architect"</CardTitle>
                <CardDescription className="text-primary font-semibold">Lead Developer</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Blockchain wizard with 5+ years building DeFi protocols. Loves coffee and clean code.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-secondary to-primary rounded-full flex items-center justify-center text-4xl">
                  📈
                </div>
                <CardTitle>Sarah "Moon Walker"</CardTitle>
                <CardDescription className="text-primary font-semibold">Growth Master</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Marketing genius who's taken 3 projects to the moon. Expert in viral campaigns and community building.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center text-4xl">
                  🎨
                </div>
                <CardTitle>Mike "Meme Lord"</CardTitle>
                <CardDescription className="text-primary font-semibold">Meme Creator</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Professional meme artist with millions of views. Turns ideas into viral content that makes people
                  smile.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold text-primary mb-2">STRUT Master Coin</h3>
              <p className="text-muted-foreground">Be the Strut. Own the Moment.</p>
            </div>
            <div className="flex gap-6">
              <Button
                variant="outline"
                size="icon"
                className="hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                <Twitter className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                <MessageCircle className="h-5 w-5" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                <Mail className="h-5 w-5" />
              </Button>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t text-center">
            <p className="text-sm text-muted-foreground">
              © 2024 STRUT Master Coin. All rights reserved. |
              <span className="font-semibold text-primary"> Not financial advice. DYOR. </span>
              Cryptocurrency investments carry risk.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
